import os
import requests
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta
from pathlib import Path
import time
import bs4 as bs
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)


def delta_date(start_date, end_date):
    """Function that returns the number of days between 2 dates """
    return abs(start_date - end_date).days


def get_tickers():
    """Method that gets the stock symbols from companies listed in the S&P 500 """
    resp = requests.get('http://en.wikipedia.org/wiki/List_of_S%26P_500_companies')
    soup = bs.BeautifulSoup(resp.text, 'lxml')
    table = soup.find_all('table')[0]  # Grab the first table

    tickers = []
    for row in table.findAll('tr')[1:]:
        ticker = row.findAll('td')[0].text.strip('\n')
        tickers.append(ticker)

    return tickers


def get_tickers_manual():
    return ['TCEHY']
    # return ['BRK-A', '600519.SS', 'CICHY', '1398.HK', '3968.HK', '300750.SZ', 'ACGBY', 'BMY', '0941.HK']
    # return ['AAPL', '2222.SR', 'MSFT', 'GOOG', 'AMZN', 'TSLA', 'BRK-A', 'FB', 'NVDA', 'TSM', 'UNH', 'JNJ', 'V', 'TCEHY', 'WMT', 'PG', 'JPM', 'XOM', '005930.KS', 'NSRGY', 'RHHBY', '600519.SS', 'MA', 'LVMUY', 'CVX', 'HD', 'BAC', 'PFE', 'LLY', 'ABBV', 'BHP', 'KO', 'NVO', 'COST', '1398.HK', 'BABA', 'ASML', 'AVGO', 'PEP', 'TM', 'DIS', 'RELIANCE.NS', 'VZ', 'TMO', 'AZN', 'MRK', 'SHEL', 'CMCSA', 'CSCO', 'OR.PA', 'ORCL', 'NKE', 'NVS', 'ABT', 'ADBE', 'ACN', 'DHR', 'INTC', 'CICHY', '3968.HK', 'MCD', 'CRM', 'WFC', 'TCS.NS', '300750.SZ', 'ACGBY', 'TMUS', 'BMY', 'UPS', 'TXN', 'NEE', 'LIN', 'PRX.AS', 'PM', 'RTX', 'QCOM', 'RY', 'UNP', 'AMD', 'MS', '0941.HK', 'PTR', 'NFLX', 'HESAF', 'MDT', 'SCHW', 'BACHF', 'AXP', 'T', 'SNY', 'HSBC', 'CVS', 'PNGAY', 'SPGI', 'AMGN', 'COP', 'TD', 'DE', 'RIO', 'LOW']
    # return ['ZION', 'ZTS']
    # return ['AAPL', 'MSFT', 'TSLA', 'GOOGL', 'AMZN', 'FB', 'NVDA', 'BRK.A', 'TCEHY', 'TSM']
    #return ["MMM","AOS","ABT","ABBV","ABMD","ACN","ATVI","ADM","ADBE","AAP","AMD","AES","AFL","A","APD","AKAM","ALK","ALB","ARE","ALGN","ALLE","LNT","ALL","GOOG","MO","AMCR","AEE","AAL","AEP","AXP","AIG","AMT","AWK","AMP","ABC","AME","AMGN","APH","ADI","ANSS","ANTM","AON","APA","AAPL","AMAT","APTV","ANET","AJG","AIZ","T","ATO","ADSK","ADP","AZO","AVB","AVY","BKR","BLL","BAC","BBWI","BAX","BDX","BBY","BIO","TECH","BIIB","BLK","BK","BA","BKNG","BWA","BXP","BSX","BMY","AVGO","BR","BRO","BF-B","CHRW","CDNS","CZR","CPB","COF","CAH","KMX","CCL","CARR","CTLT","CAT","CBOE"]


class FinnHub():
    """Class to make API calls to FinnHub"""

    def __init__(self, start_date, end_date):

        self.start_date = datetime.strptime(start_date, "%Y-%m-%d")
        self.end_date = datetime.strptime(end_date, "%Y-%m-%d")

        if self.start_date > self.end_date:
            raise Exception("'start_date' is after 'end_date'")

        if datetime.strptime(start_date, "%Y-%m-%d") <= (datetime.now() - relativedelta(years=1)):
            raise Exception("'start_date' is older than 1 year. It doesn't work with the free version of FinHub")

        self.tickers = get_tickers_manual()

        self.dir_path = os.path.dirname(os.path.realpath(__file__)) + '/news/'

        Path(self.dir_path).mkdir(parents=True, exist_ok=True)  # create new path if it doesn't exist

        # maximum api calls per minute for the finhub API
        self.max_call = 60
        # seconds to sleep before making a new API call. Default is 60 seconds as the maximum number of API calls is
        # per minute
        self.time_sleep = 60
        # nb of request made so far. Set to 0 in constructor `__init__` as we may loop through ticker
        # and want to avoid the variable to reset to 0 when exiting the wrapper `iterate_day()` (which could generate
        # an error)
        self.nb_request = 0
        # finhub unique API key. Get yours here : https://finnhub.io/
        self.finhub_key = os.getenv("API_KEY")
        self.js_data = []

        self.__get_historical_news()

    def __get_historical_news(self):
        for ticker in self.tickers:
            self.js_data.clear()
            self.ticker_request = ticker
            # call the methods to access historical financial headlines
            self.req_new()
            news_data = []
            for news in self.js_data:
                dict = {}
                dict['ticker'] = ticker
                dict['date'] = datetime.utcfromtimestamp(news['datetime'])
                dict['source'] = news['source']
                dict['title'] = news['headline']
                dict['description'] = news['summary']
                dict['url'] = news["url"]

                news_data.append(dict)
            df_news_by_company = pd.DataFrame(news_data)
            df_news_by_company.to_csv(f"news/{ticker}.csv", sep=',', encoding='utf-8', header=True)
            df_all_news = df_all_news.append(df_news_by_company)

        df_all_news.to_csv(f"news/all_news.csv", sep=',', encoding='utf-8', header=True)
        df_all_news.to_pickle(f"news/all_news.pkl")

    def iterate_day(func):
        """ Decorator that makes the API call on FinHub each days between the `self.start_date`
        and `self.end_date` """

        def wrapper_(self):
            delta_date_ = delta_date(self.start_date, self.end_date)
            date_ = self.start_date

            for item in range(delta_date_ + 1):
                self.nb_request += 1
                func(self, date_)
                date_ = date_ + relativedelta(days=1)
                if self.nb_request == (self.max_call-1):
                    time.sleep(self.time_sleep)
                    self.nb_request = 0
        return wrapper_

    @iterate_day
    def req_new(self, date_):
        """ Method that makes news request(s) to the Finnhub API"""
        date_ = date_.strftime("%Y-%m-%d")
        request_ = requests.get('https://finnhub.io/api/v1/company-news?symbol=' + self.ticker_request + '&from=' +
                                date_ + '&to=' + date_ + '&token=' + self.finhub_key)
        self.js_data += request_.json()
        print(request_.json())


if __name__ == "__main__":
    FinnHub(start_date='2021-04-22', end_date='2022-04-22')