You may find all working files of chapters in their respective folders:

Chapter 2: Implementation and results of the dictionary-based approach
Chapter 3: Implementation and results of the BERT approach
Chapter 4: Predicting the nature of the news flow at the end of the day
Applications

