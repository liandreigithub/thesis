import pandas as pd
import numpy as np

pd.set_option('mode.chained_assignment', None)


def filter_by_weekday():
    news = pd.read_csv("news/AAPL.csv", parse_dates=['date'], index_col=0)
    #  The day of the week with Monday=0, Sunday=6.
    news['weekday'] = news['date'].dt.dayofweek

    print("Count news before", len(news))
    #  выгружаем новости за вторник-среду-четверг-пятницу. не выгружаем понедельник,
    #  так как не знаем, что делать с тем, что новости могут публиковаться в субботу и воскресенье
    #  (будем смотреть предыдущий день)
    news_cut = news[news['weekday'].isin([1, 2, 3, 4])]
    #  удаляем два неинформативных источника
    news_cut = news_cut[news_cut.source != 'PR Web']
    news_cut = news_cut[news_cut.source != 'PR Newswire']
    print("Count news after", len(news_cut))

    news_cut.to_csv("news/AAPL(weekday).csv", sep=',', encoding='utf-8', header=True)
    news_cut.to_excel("news/AAPL(weekday).xlsx")


def split_df():
    news = pd.read_csv("news/AAPL(weekday).csv", parse_dates=['date'], index_col=None)

    news_part_1 = news.loc[:3999, ]
    news_part_1.to_csv("news/AAPL_part1.csv", sep=',', encoding='utf-8', header=True)

    news_part_2 = news.loc[4000:7999, ]
    news_part_2.to_csv("news/AAPL_part2.csv", sep=',', encoding='utf-8', header=True)

    news_part_4 = news.loc[8000:, ]
    news_part_4.to_csv("news/AAPL_part3.csv", sep=',', encoding='utf-8', header=True)


def split_df2():
    news = pd.read_csv("news/AAPL(weekday).csv", parse_dates=['date'], index_col=None)

    news_part_4 = news.loc[9000:9600, ]
    news_part_4.to_csv("news/AAPL_part4_1.csv", sep=',', encoding='utf-8', header=True)

    news_part_4 = news.loc[9601:10200, ]
    news_part_4.to_csv("news/AAPL_part4_2.csv", sep=',', encoding='utf-8', header=True)

    news_part_4 = news.loc[10201:10899, ]
    news_part_4.to_csv("news/AAPL_part4_3.csv", sep=',', encoding='utf-8', header=True)


def load_sentiment_analyses():
    sentiment_analysis_df = pd.read_csv("apple_news_sentiment_analysis_full.csv", index_col=0)
    # columns = ['pos_vader_title', 'pos_vader_desc', 'neg_vader_title', 'neg_vader_desc', 'Positive_harvard_title', 'Negative_harvard_title', 'word_count_harvard_title',
    #            'Positive_harvard_desc', 'word_count_harvard_desc', 'Positive_mcdonald_title',
    #            'word_count_mcdonald_title',
    #            'Positive_mcdonald_desc', 'word_count_mcdonald_desc', 'ticker', 'date', 'weekday', 'source']
    #
    # sentiment_analysis_df = sentiment_analysis_df[columns]
    sentiment_analysis_df['pos_vader_title%'] = sentiment_analysis_df['pos_vader_title'] * 100
    sentiment_analysis_df['pos_vader_desc%'] = sentiment_analysis_df['pos_vader_desc'] * 100

    sentiment_analysis_df['pos_harvard_title%'] = 100 * sentiment_analysis_df['Positive_harvard_title'] / sentiment_analysis_df['word_count_harvard_title']
    sentiment_analysis_df['pos_harvard_desc%'] = 100 * sentiment_analysis_df['Positive_harvard_desc'] / sentiment_analysis_df['word_count_harvard_desc']

    sentiment_analysis_df['pos_mcdonald_title%'] = 100 * sentiment_analysis_df['Positive_mcdonald_title'] / sentiment_analysis_df['word_count_mcdonald_title']
    sentiment_analysis_df['pos_mcdonald_desc%'] = 100 * sentiment_analysis_df['Positive_mcdonald_desc'] / sentiment_analysis_df['word_count_mcdonald_desc']

    sentiment_analysis_df['neg_vader_title%'] = sentiment_analysis_df['neg_vader_title'] * 100
    sentiment_analysis_df['neg_vader_desc%'] = sentiment_analysis_df['neg_vader_desc'] * 100

    sentiment_analysis_df['neg_harvard_title%'] = 100 * sentiment_analysis_df['Negative_harvard_title'] / sentiment_analysis_df['word_count_harvard_title']
    sentiment_analysis_df['neg_harvard_desc%'] = 100 * sentiment_analysis_df['Negative_harvard_desc'] / sentiment_analysis_df['word_count_harvard_desc']

    sentiment_analysis_df['neg_mcdonald_title%'] = 100 * sentiment_analysis_df['Negative_mcdonald_title'] / sentiment_analysis_df['word_count_mcdonald_title']
    sentiment_analysis_df['neg_mcdonald_desc%'] = 100 * sentiment_analysis_df['Negative_mcdonald_desc'] / sentiment_analysis_df['word_count_mcdonald_desc']

    return sentiment_analysis_df


#  функция добавляем столбец date_utc, на основе источника новости
#  необходимо для корректной оценки новостей по часам их выхода
def convert_date_to_utc(news):
    #  оставляем источники новостей, где мы уверены в часовом поясе
    sources = ["Nasdaq", "SeekingAlpha", "CNBC", "Reuters", "MarketWatch", "DowJones", "Yahoo", "Market News Video", "Finnhub", "Benzinga"]
    print("Было", len(news))
    news = news[news['source'].isin(sources)]
    print("Стало", len(news))
    # Было 12501
    # Стало 10319

    # источники, дата публикации которых предствлена в EDT (ED) time zone
    sourse_ED = ["Nasdaq", "SeekingAlpha", "CNBC", "MarketWatch", "DowJones", "Market News Video", "Finnhub", "Benzinga"]
    sourse_UTC = ["Reuters", "Yahoo"]

    news_ED = news[news['source'].isin(sourse_ED)]
    news_ED['date_utc'] = news_ED['date'].apply(lambda d: np.datetime64(d) + np.timedelta64(5, 'h'))

    news_UTC = news[news['source'].isin(sourse_UTC)]
    news_UTC['date_utc'] = news_UTC['date']

    frames = [news_ED, news_UTC]
    news = pd.concat(frames)

    news['date_utc'] = pd.to_datetime(news['date_utc'], format='%Y-%m-%d %H:%M:%S')

    #  разделяем дату на 3 столбца
    news['time'] = news['date_utc'].dt.time
    news['date_utc'] = news['date_utc'].dt.date
    news['hour'] = news['time'].apply(lambda x: str(x).split(':')[0])

    return news


def load_candles():
    # считываем файл с суточными ценами
    # средняя цена за 5 предыдущих суток и средняя цена текущего дня
    candles_day_df = pd.read_csv("candles/AAPL_TINKOFF_DAY.csv", sep=',', decimal=',', parse_dates=['time'], index_col=0)
    candles_day_df['date'] = candles_day_df['time'].dt.date
    candles_day_df = candles_day_df.loc[:, ['date', 'median']]
    candles_day_df['median'] = candles_day_df['median'].astype(float)
    candles_day_df['median_5_days'] = (candles_day_df['median'].shift(1, fill_value=0) +
                                       candles_day_df['median'].shift(2, fill_value=0) +
                                       candles_day_df['median'].shift(3, fill_value=0) +
                                       candles_day_df['median'].shift(4, fill_value=0) +
                                       candles_day_df['median'].shift(5, fill_value=0)) / 5

    candles_day_df.loc[0:4, 'median_5_days'] = None

    # считываем файл с ежечасными ценами для определения средней цены в часе выхода новости
    candles_hour_df = pd.read_csv("candles/AAPL_TINKOFF_HOUR.csv", sep=',', decimal=',', parse_dates=['time'], index_col=0)
    candles_hour_df['date'] = candles_hour_df['time'].dt.date
    candles_hour_df['hour'] = candles_hour_df['time'].dt.hour
    candles_hour_df = candles_hour_df.loc[:, ['date', 'hour', 'median']]

    # candles_hour_df.to_excel("цены по часам.xlsx")
    # candles_day_df.to_excel("цены по дням.xlsx")

    return candles_day_df, candles_hour_df


candles_day_df, candles_hour_df = load_candles()

sentiment_analysis_df = load_sentiment_analyses()
news = convert_date_to_utc(sentiment_analysis_df)

def myfunc1(row):
    return candles_day_df[(pd.to_datetime(candles_hour_df['date']) == row['date_utc']) & (candles_hour_df['hour'] == row['hour'])]['median']

# подтянуть цены
news['median_hour'] = None #news.apply(myfunc1, axis=1)
news['median_5_days'] = None#news['date_utc'].apply(lambda x: candles_day_df[pd.to_datetime(candles_day_df['date']) == x]['median_5_days'])
news['median_day'] = None #news['date_utc'].apply(lambda x: candles_day_df[pd.to_datetime(candles_day_df['date']) == x]['median'])
news['diff_medians'] = 0 #news['median_day'] / news['median_5_days']

# обрезка до нужного формата
cut_columns = ['date_utc', 'time', 'hour', 'median_5_days', 'median_day', 'diff_medians', 'median_hour', 'ticker', 'weekday', 'pos_vader_title%', 'pos_vader_desc%',
               'pos_harvard_title%', 'pos_harvard_desc%', 'pos_mcdonald_title%', 'pos_mcdonald_desc%',  'neg_vader_title%', 'neg_vader_desc%',
               'neg_harvard_title%', 'neg_harvard_desc%', 'neg_mcdonald_title%', 'neg_mcdonald_desc%', 'word_count_mcdonald_title', 'word_count_mcdonald_desc']

print(len(news))

news = news[cut_columns]
news.to_csv("test.csv", sep=',', encoding='utf-8', header=True)
news.to_excel("сентиментальный анализ с негативом.xlsx")