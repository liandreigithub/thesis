import pandas as pd


df = pd.read_csv('AAPL_finnbert.csv', sep=',', decimal=',', index_col=0)
print(df.finbert_title.value_counts())

# neutral     9033
# positive    4022
# negative    2727

print(df.finbert_description.value_counts())

# neutral     8353
# positive    4205
# negative    3092

count_news_by_day = df.groupby('date')['finbert_title'].count()
count_news_by_sentiment_title = df.groupby('date')['finbert_title'].value_counts()
count_news_by_sentiment_description = df.groupby('date')['finbert_description'].value_counts()

data = []
for day, df_group in df.groupby('date'):
    common_count_news = count_news_by_day[day]
    common_count_source = df_group.source.nunique()
    d = {"date": day, "count_news": common_count_news, "count_source": common_count_source}
    for sentiment, count_news in count_news_by_sentiment_title[day].iteritems():
        d[f"{sentiment}_title"] = count_news / common_count_news

    for sentiment, count_news in count_news_by_sentiment_description[day].iteritems():
        d[f"{sentiment}_description"] = count_news / common_count_news

    data.append(d)

df_news = pd.DataFrame(data)
df_news = df_news.fillna(0)

df_price = pd.read_csv("AAPL_price.csv", sep=',', decimal=',', parse_dates=['time'])
df_price['date'] = df_price['time'].dt.date
df_price = df_price.loc[:, ['date', 'median']]
df_price['median'] = df_price['median'].astype(float)

df_price['median_5_days'] = (df_price['median'].shift(1,fill_value=0) +
df_price['median'].shift(2, fill_value=0) +
df_price['median'].shift(3, fill_value=0) +
df_price['median'].shift(4, fill_value=0) +
df_price['median'].shift(5, fill_value=0)) / 5

df_price.loc[0:4, 'median_5_days'] = None

df_price['diff_medians'] = df_price['median'] - df_price['median_5_days']
df_price['diff_medians%'] = (df_price['diff_medians'] / df_price['median_5_days']) * 100
df_price.dropna(inplace=True)

df_price['date'] = pd.to_datetime(df_price['date'], format="%Y/%m/%d")
df_news['date'] = pd.to_datetime(df_news['date'], format="%Y/%m/%d")

common_df = pd.merge(df_price, df_news, on='date')
common_df.to_csv("FINBERT.csv",  sep=',', encoding='utf-8', header=True)
common_df.to_excel("FINBERT.xlsx")






